export { default } from './toggle-view';
