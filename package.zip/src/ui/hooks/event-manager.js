import {EventEmitter} from 'fbemitter';
export default new EventEmitter();