export { default } from './search-results';
