export { default } from './resume-search.js';
