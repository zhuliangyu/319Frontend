export { default } from './profile-page';
