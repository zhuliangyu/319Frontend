export { default } from './page-title-search.js';
