export { default } from './page-title-banner.js';
