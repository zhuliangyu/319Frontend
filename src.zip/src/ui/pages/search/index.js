export { default } from './search-page';
