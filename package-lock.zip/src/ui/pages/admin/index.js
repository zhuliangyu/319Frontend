export { default } from './admin-page';
