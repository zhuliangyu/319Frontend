import React from 'react';

const Footer = () => {

  return (
    <div >
      © Associated Engineering 2021-23. All Rights Reserved. 
      Treat all data as confidential.
    </div>
  );


}

export default Footer;